# R Workshop — College of Social & Behavioral Sciences

Josh McCrain (josh.mccrain@utah.edu).

## Before Day 2

1. If you missed Day 1: install **R** (<https://cran.r-project.org>) and then
   **RStudio Desktop** (<https://posit.co/download/rstudio-desktop/>). Both
   free. R first, RStudio second.
2. **Install the packages before you arrive.** Open RStudio, paste this line
   into the Console (bottom-left), and hit Enter:

   ```r
   install.packages(c("tidyverse", "janitor", "sf", "broom"))
   ```

   It takes a few minutes. If it asks "Do you want to install from sources
   the packages which need compilation?", answer **no**.
3. Check that it worked. Paste this and hit Enter:

   ```r
   library(tidyverse); library(sf)
   ```

   Some messages are normal. If you see the word **Error**, debug with an LLM
4. Unzip `R_workshop_day2.zip` into your "R Workshop" folder. You should end
   up with `day2_tidyverse.R` sitting next to a `data/` folder.

## Day 2 files

| File | What it is |
|:--|:--|

| `data/counties.csv` | County-level MRP estimates of support for civilian oversight of police, with census and election covariates. |
| `data/county_opinion.csv` | County MRP estimates from the Cooperative Election Study: body camera support and feeling safe, 2016–2022. |
| `data/oversight_agencies.csv` | Database of U.S. civilian police oversight agencies. Deliberately left messy. |
| `data/counties_sf.rds`, `data/states_sf.rds` | County and state boundaries for maps (U.S. Census, 2020). |
| `data/criminalrecord.csv` | Pager (2003) audit study data, from Day 1. |

## Day 1 files

| File | What it is |
|:--|:--|
| `day1_intro_to_R.R` | Day 1. |
| `data/criminalrecord.csv` | Pager (2003) audit study example data. |
